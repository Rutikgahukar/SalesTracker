package com.example.locationdetect;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.ArrayList;
import java.util.List;

public class TrackSalesExecutive extends AppCompatActivity implements OnMapReadyCallback {
    private MapView mapView;
    private GoogleMap googleMap;
    private DatabaseReference databaseReference;
    private Spinner userSpinner;
    private ArrayAdapter<String> spinnerAdapter;
    private List<String> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_sales_executive);

        // Initialize MapView
        mapView = findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        // Initialize Spinner and populate user list
        userSpinner = findViewById(R.id.spinner);
        userList = new ArrayList<>();
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, userList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userSpinner.setAdapter(spinnerAdapter);

        userSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = userList.get(position);
                String selectedUid = extractUidFromSelectedItem(selectedItem);

                // Fetch and display locations for the selected user
                displayUserLocations(selectedUid);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(TrackSalesExecutive.this, "Please select a user", Toast.LENGTH_SHORT).show();
            }
        });

        // Populate user list from Firebase
        fetchUserList();
    }

    private void fetchUserList() {
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        usersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userList.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String uid = snapshot.getKey();
                    String userName = snapshot.child("username").getValue(String.class);
                    if (uid != null && userName != null) {
                        userList.add(userName + " (UID: " + uid + ")");
                    }
                }

                spinnerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(TrackSalesExecutive.this, "Error fetching user list", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String extractUidFromSelectedItem(String selectedItem) {
        int start = selectedItem.lastIndexOf("(") + 5;
        int end = selectedItem.lastIndexOf(")");
        return selectedItem.substring(start, end).trim();
    }

    private void displayUserLocations(String selectedUid) {
        Log.d("SelectedUID", selectedUid);
        databaseReference = FirebaseDatabase.getInstance().getReference("locations");
        DatabaseReference userLocationsRef = databaseReference.child(selectedUid);
        Log.d("userLocation",""+userLocationsRef);

        userLocationsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                googleMap.clear();
                PolylineOptions polylineOptions = new PolylineOptions();
                polylineOptions.color(Color.BLUE);

                List<LatLng> coordinates = new ArrayList<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Double latitudeDouble = snapshot.child("latitude").getValue(Double.class);
                    Double longitudeDouble = snapshot.child("longitude").getValue(Double.class);

                    if (latitudeDouble != null && longitudeDouble != null) {
                        double latitude = latitudeDouble;
                        double longitude = longitudeDouble;

                        LatLng location = new LatLng(latitude, longitude);
                        coordinates.add(location);

                        googleMap.addMarker(new MarkerOptions().position(location));
                    }
                }

                polylineOptions.addAll(coordinates);
                googleMap.addPolyline(polylineOptions);

                if (!coordinates.isEmpty()) {
                    LatLng lastLatLng = coordinates.get(coordinates.size() - 1);
                    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lastLatLng, 15));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(TrackSalesExecutive.this, "Error fetching locations", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}
